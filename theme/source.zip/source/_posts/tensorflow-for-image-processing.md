---
title: Tnsorflow for Image Processing
date: 2017-04-30 13:58:58
tags: [tensorflow, Image Processing, mnist]
---
前几天简单的学习了一下tensorflow，也跑了mnist官方demo，一只在想一个问题：如何用自己的图片数据来跑tensorflow。就从昨天开始一步一步来探索这个问题，和我一起来看看是如何解决这个问题的吧。
#### 引言
平时在实验室做的都是图像相关的研究，用的最多的框架是caffe，caffe容易上手但是在多GPU并行方面表现得却令人失望，所以从caffe转战tensorflow从去年开始就有这个想法，现在tensorflow也逐渐稳定，也有了Windows版本，就开始了在tensorflow下探索学习。

#### 关于MNIST
做图像mnist数据肯定是大家都熟悉的一个数据集，但到tensorflow跑mnist demo时候却发现一个问题，在我训练时候，我是不知道mnist数据是如何在训练时候调用的，也就是官方版给了一个压缩包然后里面是二进制的数据，这对我来说像一个黑匣子，摸不透里面的东西，也不能用自己的图片数据跑程序，然后我找到了这一篇文章[MNIST数据集解析](http://m.blog.csdn.net/article/details?id=53257185)，这篇文章详细讲解了官网上说的mnist二进制文件是如何读数据的。
#### 开始沿着mnist demo走
[demo](https://github.com/mrlittlepig/MorvanTensorflow/blob/master/Neural%20Network/Convolutional.py)里面mnist相关的代码：

```python
from tensorflow.examples.tutorials.mnist import input_data

mnist = input_data.read_data_sets('../MNIST_data', one_hot=True)
......
for i in range(1000):
    batch_xs, batch_ys = mnist.train.next_batch(100)
    sess.run(train_step, feed_dict={xs: batch_xs, ys: batch_ys, keep_prob: 0.5})
    if i % 50 == 0:
        print(compute_accuracy(
            mnist.test.images, mnist.test.labels))
```
修改下路径很容易就跑起来了，但调用数据的方式是
```
batch_xs, batch_ys = mnist.train.next_batch(100)
```
其中我大概看了下[源代码](https://github.com/tensorflow/tensorflow/blob/master/tensorflow/contrib/learn/python/learn/datasets/mnist.py)的核心部分

``` python
def read_data_sets(train_dir,
                   fake_data=False,
                   one_hot=False,
                   dtype=dtypes.float32,
                   reshape=True,
                   validation_size=5000,
                   seed=None):
  if fake_data:

    def fake():
      return DataSet(
          [], [], fake_data=True, one_hot=one_hot, dtype=dtype, seed=seed)

    train = fake()
    validation = fake()
    test = fake()
    return base.Datasets(train=train, validation=validation, test=test)

  TRAIN_IMAGES = 'train-images-idx3-ubyte.gz'
  TRAIN_LABELS = 'train-labels-idx1-ubyte.gz'
  TEST_IMAGES = 't10k-images-idx3-ubyte.gz'
  TEST_LABELS = 't10k-labels-idx1-ubyte.gz'

  local_file = base.maybe_download(TRAIN_IMAGES, train_dir,
                                   SOURCE_URL + TRAIN_IMAGES)
  with open(local_file, 'rb') as f:
    train_images = extract_images(f)

  local_file = base.maybe_download(TRAIN_LABELS, train_dir,
                                   SOURCE_URL + TRAIN_LABELS)
  with open(local_file, 'rb') as f:
    train_labels = extract_labels(f, one_hot=one_hot)

  local_file = base.maybe_download(TEST_IMAGES, train_dir,
                                   SOURCE_URL + TEST_IMAGES)
  with open(local_file, 'rb') as f:
    test_images = extract_images(f)

  local_file = base.maybe_download(TEST_LABELS, train_dir,
                                   SOURCE_URL + TEST_LABELS)
  with open(local_file, 'rb') as f:
    test_labels = extract_labels(f, one_hot=one_hot)

  if not 0 <= validation_size <= len(train_images):
    raise ValueError(
        'Validation size should be between 0 and {}. Received: {}.'
        .format(len(train_images), validation_size))

  validation_images = train_images[:validation_size]
  validation_labels = train_labels[:validation_size]
  train_images = train_images[validation_size:]
  train_labels = train_labels[validation_size:]

  train = DataSet(
      train_images, train_labels, dtype=dtype, reshape=reshape, seed=seed)
  validation = DataSet(
      validation_images,
      validation_labels,
      dtype=dtype,
      reshape=reshape,
      seed=seed)
  test = DataSet(
      test_images, test_labels, dtype=dtype, reshape=reshape, seed=seed)

  return base.Datasets(train=train, validation=validation, test=test)
```
其中获取图片和标签的代码：

``` python
train_images = extract_images(f)
train_labels = extract_labels(f, one_hot=one_hot)
test_images = extract_images(f)
test_labels = extract_labels(f, one_hot=one_hot)
```
然后查看了相关函数

```
def extract_images(f):
  """Extract the images into a 4D uint8 numpy array [index, y, x, depth].
  Args:
    f: A file object that can be passed into a gzip reader.
  Returns:
    data: A 4D uint8 numpy array [index, y, x, depth].
  Raises:
    ValueError: If the bytestream does not start with 2051.
  """
  print('Extracting', f.name)
  with gzip.GzipFile(fileobj=f) as bytestream:
    magic = _read32(bytestream)
    if magic != 2051:
      raise ValueError('Invalid magic number %d in MNIST image file: %s' %
                       (magic, f.name))
    num_images = _read32(bytestream)
    rows = _read32(bytestream)
    cols = _read32(bytestream)
    buf = bytestream.read(rows * cols * num_images)
    data = numpy.frombuffer(buf, dtype=numpy.uint8)
    data = data.reshape(num_images, rows, cols, 1)
    return data
```
从with gzip.GzipFile(fileobj=f) as bytestream:这句话开始，下面就在解析mnist数据集如上面我给的网址里面解析的方式一样，后面就全是在读图片，存放在data里面，经过调整数据的结构然后返回了，同样的extract_labels函数实现如下

```python
def extract_labels(f, one_hot=False, num_classes=10):
  """Extract the labels into a 1D uint8 numpy array [index].
  Args:
    f: A file object that can be passed into a gzip reader.
    one_hot: Does one hot encoding for the result.
    num_classes: Number of classes for the one hot encoding.
  Returns:
    labels: a 1D uint8 numpy array.
  Raises:
    ValueError: If the bystream doesn't start with 2049.
  """
  print('Extracting', f.name)
  with gzip.GzipFile(fileobj=f) as bytestream:
    magic = _read32(bytestream)
    if magic != 2049:
      raise ValueError('Invalid magic number %d in MNIST label file: %s' %
                       (magic, f.name))
    num_items = _read32(bytestream)
    buf = bytestream.read(num_items)
    labels = numpy.frombuffer(buf, dtype=numpy.uint8)
    if one_hot:
      return dense_to_one_hot(labels, num_classes)
    return labels
```
也就是在调用data和labels时候将原有的二进制文件里面的数据替换掉即可，于是网上发现一篇文章[利用Python PIL、cPickle读取和保存图像数据库](http://www.2cto.com/kf/201501/373645.html)再结合自己了解的numpy知识写了一个直接读取图片数据然后给tensorflow训练的方法,在mnist数据代码里面稍作修改[GitHub地址](https://github.com/mrlittlepig/ImageProcessing/blob/master/datasets/imnist.py)

```python
# imnist.py

def read_data_sets(data_dir,
                   one_hot=False,
                   dtype=dtypes.float32,
                   reshape=True,
                   validation_size=5000,
                   seed=None):

    TRAIN = data_dir + 'mnist_train/train.txt'
    TEST = data_dir + 'mnist_test/test.txt'
    # from tensorflow.examples.tutorials.mnist import input_data
    # train and test from images and txt labels
    train_images, train_labels = process_images(TRAIN, one_hot=one_hot)
    test_images, test_labels = process_images(TEST, one_hot=one_hot)

    if not 0 <= validation_size <= len(train_images):
        raise ValueError(
            'Validation size should be between 0 and {}. Received: {}.'
                .format(len(train_images), validation_size))

    validation_images = train_images[:validation_size]
    validation_labels = train_labels[:validation_size]
    train_images = train_images[validation_size:]
    train_labels = train_labels[validation_size:]

    train = DataSet(
        train_images, train_labels, dtype=dtype, reshape=reshape, seed=seed)
    validation = DataSet(
        validation_images,
        validation_labels,
        dtype=dtype,
        reshape=reshape,
        seed=seed)
    test = DataSet(
        test_images, test_labels, dtype=dtype, reshape=reshape, seed=seed)

    return base.Datasets(train=train, validation=validation, test=test)
```

其中核心部分在process_images这个函数，其实现如下：

```python
# imnist.py

def process_images(label_file, one_hot=False, num_classes=10):
    if file.getFileName(label_file) == 'train.txt':
    # 60000张训练图片，每张是28x28的尺寸所以是784
    # 标签也是60000个
        images = numpy.empty((60000, 784))
        labels = numpy.empty(60000)
        
    # 测试集
    if file.getFileName(label_file) == 'test.txt':
        images = numpy.empty((10000, 784))
        labels = numpy.empty(10000)
        
    lines = readLines(label_file)
    # 将标签存在字典里面方便从图片名读取标签
    label_record = map(lines)
    file_name_length = len(file.getFileName(label_file))
    image_dir = label_file[:-1*file_name_length]
    print(len(label_record))
    index = 0
    
    # 遍历字典来把图片存放在image里面生成img_ndarray
    # 把标签存放在labels里面
    for name in label_record:
        # print label_record[name]
        image = Image.open(image_dir + str(label_record[name]) + '/' + name)
        print("processing %d: " % index + image_dir + str(label_record[name]) + '/' + name)

        img_ndarray = numpy.asarray(image, dtype='float32')
        images[index] = numpy.ndarray.flatten(img_ndarray)
        labels[index] = numpy.int(label_record[name])

        index = index + 1
    print(index)
    num_images = index
    rows = 28
    cols = 28
    
    # 用one_hot格式来存放标签 
    # 有关one_hot可以看https://www.zhihu.com/question/53021606
    if one_hot:
      return images.reshape(num_images, rows, cols, 1), dense_to_one_hot(numpy.array(labels, dtype=numpy.uint8), num_classes)
    return images.reshape(num_images, rows, cols, 1), numpy.array(labels, dtype=numpy.uint8)
```
#### 开始跑实验
有关网络和数据读取方式如下

```python
# classification.py

import tensorflow as tf
from datasets import imnist

mnist = imnist.read_data_sets('./MNIST_data/', one_hot=True)

def compute_accuracy(v_xs, v_ys):
    global prediction
    y_pre = sess.run(prediction, feed_dict={xs: v_xs, keep_prob: 1})
    correct_prediction = tf.equal(tf.argmax(y_pre,1), tf.argmax(v_ys,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    result = sess.run(accuracy, feed_dict={xs: v_xs, ys: v_ys, keep_prob: 1})
    return result

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

def conv2d(x, W):
    # stride [1, x_movement, y_movement, 1]
    # Must have strides[0] = strides[3] = 1
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

def max_pool_2x2(x):
    # stride [1, x_movement, y_movement, 1]
    return tf.nn.max_pool(x, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')

# define placeholder for inputs to network
xs = tf.placeholder(tf.float32, [None, 784])/255.   # 28x28
ys = tf.placeholder(tf.float32, [None, 10])
keep_prob = tf.placeholder(tf.float32)
x_image = tf.reshape(xs, [-1, 28, 28, 1])
# print(x_image.shape)  # [n_samples, 28,28,1]

## conv1 layer ##
W_conv1 = weight_variable([5,5, 1,32]) # patch 5x5, in size 1, out size 32
b_conv1 = bias_variable([32])
h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1) # output size 28x28x32
h_pool1 = max_pool_2x2(h_conv1)                                         # output size 14x14x32

## conv2 layer ##
W_conv2 = weight_variable([5,5, 32, 64]) # patch 5x5, in size 32, out size 64
b_conv2 = bias_variable([64])
h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2) # output size 14x14x64
h_pool2 = max_pool_2x2(h_conv2)                                         # output size 7x7x64

## fc1 layer ##
W_fc1 = weight_variable([7*7*64, 1024])
b_fc1 = bias_variable([1024])
# [n_samples, 7, 7, 64] ->> [n_samples, 7*7*64]
h_pool2_flat = tf.reshape(h_pool2, [-1, 7*7*64])
h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

## fc2 layer ##
W_fc2 = weight_variable([1024, 10])
b_fc2 = bias_variable([10])
prediction = tf.nn.softmax(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)



# the error between prediction and real data
cross_entropy = tf.reduce_mean(-tf.reduce_sum(ys * tf.log(prediction),
                                              reduction_indices=[1]))       # loss
train_step = tf.train.AdamOptimizer(1e-4).minimize(cross_entropy)

sess = tf.Session()

init = tf.global_variables_initializer()
sess.run(init)

for i in range(1000):
    batch_xs, batch_ys = mnist.train.next_batch(100)
    sess.run(train_step, feed_dict={xs: batch_xs, ys: batch_ys, keep_prob: 0.5})
    if i % 50 == 0:
        print(compute_accuracy(
            mnist.test.images, mnist.test.labels))
```
从表面看上去和官方调用方式没区别，但实质上是从图片文件夹里面读取图片和标签来进行训练的，可以将文件夹图片换成自己的图片数据进行训练，所有代码和数据都保存在我的GitHub仓库里面：[ImageProcessing](https://github.com/mrlittlepig/ImageProcessing)如果觉得对你有帮助的话记得给我的repo点一个star，谢谢大家，后期我会不定期对代码进行更新维护。

[GitHub](https://github.com/mrlittlepig/ImageProcessing) 
